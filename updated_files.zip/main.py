"""
main.py
=======
Application entrypoint.

Run development server:
    uv run python main.py

Or via uvicorn directly:
    uv run uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

from __future__ import annotations

import uvicorn
import typer

from backend.api.app import create_app
from backend.shared.config import get_settings

# WSGI/ASGI application object (used by uvicorn when passed as module:attr)
app = create_app()

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

cli = typer.Typer(name="paeka", add_completion=False)


@cli.command()
def serve(
    host: str = typer.Option(None, help="Override server host"),
    port: int = typer.Option(None, help="Override server port"),
    reload: bool = typer.Option(None, help="Enable hot-reload (dev mode)"),
) -> None:
    """Start the PAEKA FastAPI server."""
    settings = get_settings()
    uvicorn.run(
        "main:app",
        host=host or settings.server.host,
        port=port or settings.server.port,
        reload=reload if reload is not None else settings.server.reload,
        log_config=None,  # we handle logging ourselves
    )


def app_cli() -> None:
    cli()


if __name__ == "__main__":
    serve()
