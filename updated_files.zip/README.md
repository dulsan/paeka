# PAEKA

**Personal AI Engineering & Knowledge Assistant** — fully self-hosted.

| Component | Technology |
|---|---|
| LLM Runtime | SGLang + Qwen3-14B-Instruct |
| Vector DB | Weaviate (hybrid dense+BM25 search) |
| Embeddings | BAAI/bge-m3 |
| Reranker | BAAI/bge-reranker-large |
| Document Parsing | Docling (primary) · Marker (fallback) · openpyxl+pandas |
| Knowledge Graph | NetworkX + SQLite |
| Memory | LLM-extracted summaries + global facts |
| Skills | TOML-defined prompt behaviours |
| API | FastAPI + async SQLite (aiosqlite) |

## Quick Start

```bash
uv sync
docker compose up -d
uv run uvicorn main:app --reload
curl http://localhost:8000/api/health
```

See [SETUP.md](SETUP.md) for full setup instructions.
See [API_REFERENCE.md](API_REFERENCE.md) for all endpoints.
